from json import loads as jsloads
import re
from cocoscrapers.modules import client
from cocoscrapers.modules import source_utils, cache
from cocoscrapers.modules.control import homeWindow, sleep

############KODI-RD-IL###################
import sys,xbmcvfs
dependencies = xbmcvfs.translatePath('special://home/addons/script.module.cocoscrapers/lib/cocoscrapers/modules/kodirdil')
sys.path.append(dependencies)
from cocoscrapers.modules.kodirdil import lzstring
#########################################

class source:
    priority = 1
    pack_capable = True
    hasMovies = True
    hasEpisodes = True
    def __init__(self):
        self.language = ['en']
        # APROPO DMM Hashlists
        self.dmm_hashlists_list = "https://pastebin.com/raw/rkSXDyrX"
        self.bypass_filter = 'false'

    def _get_files(self):
        if self.get_pack_files: return []
        
        hashlists_response = client.request(self.dmm_hashlists_list, timeout=10)
        
        # Extract hashlists URLs matching the pattern, ignore comments.
        pattern = r"https://hashlists\.debridmediamanager\.com/[^\s]+"
        hashlists = re.findall(pattern, hashlists_response)
        
        torrents_list = []  # List to store all torrents collected

        # Loop through each hashlists URL
        for hashlist in hashlists:
            response = client.request(hashlist, timeout=10)

            # Extracting the iframe match
            iframe_regex = r'<iframe src="https:\/\/debridmediamanager.com\/hashlist#(.*)"><\/iframe>'
            match = re.search(iframe_regex, response)
            
            if not match: continue
        
            # Decode the matched string
            results = lzstring.LZString().decompressFromEncodedURIComponent(match.group(1))
        
            try:
                # Load the results as JSON
                results = jsloads(results)

                # Check if 'torrents' key exists
                if isinstance(results, dict) and 'torrents' in results:
                    # Append the 'torrents' array to the torrents_list
                    torrents_list.extend(results['torrents'])
                else:
                    # If 'torrents' does not exist, append the original results
                    torrents_list.extend(results)

            except json.JSONDecodeError:
                # Handle the case where decompressed results are not valid JSON
                continue  # Skip to the next URL on error
    
        return torrents_list  # Return the consolidated list of torrents

    def sources(self, data, hostDict):
        self.get_pack_files = False
        sources = []
        if not data:
            homeWindow.clearProperty('cocoscrapers.apropo_dmm.performing_single_scrape')
            return sources
        sources_append = sources.append
        try:
            aliases = data['aliases']
            year = data['year']
            imdb = data['imdb']
            if 'tvshowtitle' in data:
                homeWindow.setProperty('cocoscrapers.apropo_dmm.performing_single_scrape', 'true')
                title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
                episode_title = data['title']
                season = data['season']
                episode = data['episode']
                hdlr = 'S%02dE%02d' % (int(season), int(episode))
                years = None
                files = cache.get(self._get_files, 10)
            else:
                title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                episode_title = None
                hdlr = year
                years = [str(int(year)-1), str(year), str(int(year)+1)]
                files = self._get_files()
                
            homeWindow.clearProperty('cocoscrapers.apropo_dmm.performing_single_scrape')
            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()
        except:
            homeWindow.clearProperty('cocoscrapers.apropo_dmm.performing_single_scrape')
            source_utils.scraper_error('APROPO_DMM')
            return sources

        for file in files:
            try:
                hash = file['hash']
                name = source_utils.clean_name(file['filename'])
                size = float(file['bytes']) / (1024 ** 3)
                
                if self.bypass_filter == 'false':
                    if not source_utils.check_title(title, aliases, name, hdlr, year, years): continue
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                if source_utils.remove_lang(name_info, check_foreign_audio): continue
                if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

                if not episode_title: # filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
                    ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
                    name_lower = name.lower()
                    if any(re.search(item, name_lower) for item in ep_strings): continue

                url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
                
                quality, info = source_utils.get_release_quality(name_info, url)

                sources_append({'provider': 'apropo_dmm', 'source': 'torrent', 'seeders': 0, 'hash': hash, 'name': name, 'name_info': name_info,
                                            'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': size})
            except:
                homeWindow.clearProperty('cocoscrapers.apropo_dmm.performing_single_scrape')
                source_utils.scraper_error('APROPO_DMM')
        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
        self.get_pack_files = True
        sources = []
        if not data: return sources
        count, finished_single_scrape = 0, False
        sleep(2000)
        while count < 10000 and not finished_single_scrape:
            finished_single_scrape = homeWindow.getProperty('cocoscrapers.apropo_dmm.performing_single_scrape') != 'true'
            sleep(100)
            count += 100
        if not finished_single_scrape: return sources
        sources_append = sources.append
        try:
            title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
            aliases = data['aliases']
            imdb = data['imdb']
            year = data['year']
            season = data['season']
            files = cache.get(self._get_files, 10)
            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()
        except:
            source_utils.scraper_error('APROPO_DMM')
            return sources

        for file in files:
            try:
                hash = file['hash']
                name = source_utils.clean_name(file['filename'])
                size = float(file['bytes']) / (1024 ** 3)
                
                if self.bypass_filter == 'true': bypass_filter = True

                episode_start, episode_end = 0, 0
                if not search_series:
                    if not bypass_filter:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
                        if not valid: continue
                    package = 'season'

                elif search_series:
                    if not bypass_filter:
                        valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
                        if not valid: continue
                    else: last_season = total_seasons
                    package = 'show'

                name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
                if source_utils.remove_lang(name_info, check_foreign_audio): continue
                if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

                url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

                quality, info = source_utils.get_release_quality(name_info, url)

                item = {'provider': 'apropo_dmm', 'source': 'torrent', 'seeders': 0, 'hash': hash, 'name': name, 'name_info': name_info, 'quality': quality,
                            'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': size, 'package': package}
                if search_series: item.update({'last_season': last_season})
                elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
                sources_append(item)
            except:
                source_utils.scraper_error('APROPO_DMM')
        return sources