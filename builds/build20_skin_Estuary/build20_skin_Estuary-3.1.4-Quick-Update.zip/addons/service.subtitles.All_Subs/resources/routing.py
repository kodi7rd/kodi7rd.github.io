

def routing(argv1,argv2):
    from resources.service import refresh_list
    
    refresh_list(arg)
    