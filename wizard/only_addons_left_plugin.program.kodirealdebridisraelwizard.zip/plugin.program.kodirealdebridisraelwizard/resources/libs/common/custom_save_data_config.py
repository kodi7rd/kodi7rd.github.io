def set_custom_save_data_variables_from_json():
    try:
        ######################################################################
        #        KODI_RD_ISRAEL Save Data Menu Imports                       #
        import sys
        import json
        import urllib.request
        from urllib.parse import urljoin
        import ssl
        import xbmc
        from resources.libs.common import logging
        from resources.libs.common.config import CONFIG

        # Create an SSL context that allows SSL verification to be skipped
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        ######################################################################

        # Run only if NOT first install of build.
        if CONFIG.get_setting('installed') not in ('false', 'ignored'):

            # GitHub link for custom_save_data_config.json file
            custom_save_data_config_github_url = "https://raw.githubusercontent.com/kodi7rd/kodi7rd.github.io/master/wizard/assets/custom_save_data_config/custom_save_data_config.json"
            addons_whitelist_github_url = "https://raw.githubusercontent.com/kodi7rd/kodi7rd.github.io/master/wizard/assets/custom_save_data_config/whitelist.txt"
             
            # Load the configuration from the JSON file
            with urllib.request.urlopen(custom_save_data_config_github_url, context=context) as response:
                custom_save_data_config = json.loads(response.read().decode('utf-8'))
                
            # Log JSON
            logging.log("custom_save_data_config.json: " + str(custom_save_data_config), level=xbmc.LOGINFO)
            
            # Exist if use JSON file from Github is false.
            USE_JSON_FILE = str(custom_save_data_config.get('USE_JSON_FILE', 'false')).lower()
            
            logging.log("USE_JSON_FILE: " + USE_JSON_FILE, level=xbmc.LOGINFO)
            if USE_JSON_FILE == 'false':
                return        

            # Override the variables based on the configuration
            CONFIG.KEEPTRAKT = str(custom_save_data_config.get('CONFIG.KEEPTRAKT', CONFIG.KEEPTRAKT)).lower() if 'CONFIG.KEEPTRAKT' in custom_save_data_config else CONFIG.KEEPTRAKT
            CONFIG.KEEPDEBRID = str(custom_save_data_config.get('CONFIG.KEEPDEBRID', CONFIG.KEEPDEBRID)).lower() if 'CONFIG.KEEPDEBRID' in custom_save_data_config else CONFIG.KEEPDEBRID
            CONFIG.KEEPLOGIN = str(custom_save_data_config.get('CONFIG.KEEPLOGIN', CONFIG.KEEPLOGIN)).lower() if 'CONFIG.KEEPLOGIN' in custom_save_data_config else CONFIG.KEEPLOGIN
            CONFIG.KEEPFENDATA = str(custom_save_data_config.get('CONFIG.KEEPFENDATA', CONFIG.KEEPFENDATA)).lower() if 'CONFIG.KEEPFENDATA' in custom_save_data_config else CONFIG.KEEPFENDATA
            CONFIG.KEEPFAVS = str(custom_save_data_config.get('CONFIG.KEEPFAVS', CONFIG.KEEPFAVS)).lower() if 'CONFIG.KEEPFAVS' in custom_save_data_config else CONFIG.KEEPFAVS
            CONFIG.KEEPSOURCES = str(custom_save_data_config.get('CONFIG.KEEPSOURCES', CONFIG.KEEPSOURCES)).lower() if 'CONFIG.KEEPSOURCES' in custom_save_data_config else CONFIG.KEEPSOURCES
            CONFIG.KEEPADVANCED = str(custom_save_data_config.get('CONFIG.KEEPADVANCED', CONFIG.KEEPADVANCED)).lower() if 'CONFIG.KEEPADVANCED' in custom_save_data_config else CONFIG.KEEPADVANCED
            CONFIG.KEEPPROFILES = str(custom_save_data_config.get('CONFIG.KEEPPROFILES', CONFIG.KEEPPROFILES)).lower() if 'CONFIG.KEEPPROFILES' in custom_save_data_config else CONFIG.KEEPPROFILES
            CONFIG.KEEPPLAYERCORE = str(custom_save_data_config.get('CONFIG.KEEPPLAYERCORE', CONFIG.KEEPPLAYERCORE)).lower() if 'CONFIG.KEEPPLAYERCORE' in custom_save_data_config else CONFIG.KEEPPLAYERCORE
            CONFIG.KEEPGUISETTINGS = str(custom_save_data_config.get('CONFIG.KEEPGUISETTINGS', CONFIG.KEEPGUISETTINGS)).lower() if 'CONFIG.KEEPGUISETTINGS' in custom_save_data_config else CONFIG.KEEPGUISETTINGS
            CONFIG.KEEPREPOS = str(custom_save_data_config.get('CONFIG.KEEPREPOS', CONFIG.KEEPREPOS)).lower() if 'CONFIG.KEEPREPOS' in custom_save_data_config else CONFIG.KEEPREPOS
            CONFIG.KEEPSUPER = str(custom_save_data_config.get('CONFIG.KEEPSUPER', CONFIG.KEEPSUPER)).lower() if 'CONFIG.KEEPSUPER' in custom_save_data_config else CONFIG.KEEPSUPER
            CONFIG.KEEPWHITELIST = str(custom_save_data_config.get('CONFIG.KEEPWHITELIST', CONFIG.KEEPWHITELIST)).lower() if 'CONFIG.KEEPWHITELIST' in custom_save_data_config else CONFIG.KEEPWHITELIST

    except Exception: 
        pass
